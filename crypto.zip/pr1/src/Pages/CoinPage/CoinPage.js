import React,{useState, useContext, useEffect} from 'react';
import './CoinPage.css';
import {useParams} from "react-router-dom";
import {Context} from "../../App.js";
import {SingleCoin} from "../../config/api.js";

import CoinInfo from "../../Components/CoinInfo/CoinInfo";

import ReactHtmlParser from 'react-html-parser';
import { Circles } from  'react-loader-spinner';


export function numberWithCommas(x){
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


const CoinPage = () => {
  
  const{id} = useParams();

  const[coin, setCoin] = useState();
  const[loading, setLoading] = useState(false);


  const { currency } = useContext(Context);

  const fetchCoin = async () => {
    try{
      setLoading(true);
      const data = await fetch(SingleCoin(id)).then((res) => res.json());
      if(data){
        setCoin(data);
        // console.log(data);
   
      }
      setLoading(false);

    }catch(err){
      console.log(err);
    }
 
  }

  useEffect(()=>{
    fetchCoin();
  },[])

  if(!coin) return <div className="load_circle"><Circles
  height="80"
  width="80"
  color="white"
  ariaLabel="circles-loading"
  wrapperStyle={{}}
  wrapperClass=""
  visible={true}
/></div>

  return (
    <div className="coin_page">
    
      <div className="width">
      <div className="top_bar">
        <img src={coin?.image.large} alt={coin?.name} className="coinpage_image"/>
        <h1>{coin?.name}</h1>
        <h4 className="coin_description">{ReactHtmlParser(coin?.description.en.split(". ")[0])}.</h4>
        <div className="market_data">
          <b>Rank : </b><span>{coin?.market_cap_rank}</span><br/>
          <span><b>Current Price : </b>{currency==="INR" ? "₹" : "$"} {numberWithCommas(coin?.market_data?.current_price[currency.toLowerCase()])}
          </span><br/>

          {/* <span><b>Market Cap : </b>{currency==="INR" ? "₹" : "$"}  {numberWithCommas(coin?.market_cap?.toString().slice(0,-6))}M</span> */}
        </div>
      </div>
      <hr className="line"/>
      <div className="chart">
        <CoinInfo coin={coin}/>
      </div>
      </div>
      
    </div>
  
  );
};
export default CoinPage;
