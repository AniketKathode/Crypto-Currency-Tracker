import React from "react";
import "./HomePage.css";

import Banner from "../../Components/Banner/Banner";
import CoinsTable from "../../Components/CoinsTable/CoinsTable";

const HomePage = () => {
  return(
    <div >
      <div className="home_page">
        <Banner/>
        <CoinsTable/>
      </div>
    </div>
  )
}
export default HomePage;