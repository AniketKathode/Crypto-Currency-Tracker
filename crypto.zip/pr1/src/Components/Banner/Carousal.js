import React,{useState, useEffect, useContext} from "react";
import "./Carousal.css";

import { Link } from "react-router-dom";

import {Context} from "../../App.js"

import AliceCarousel from 'react-alice-carousel';

import {TrendingCoins} from "../../config/api.js"

import { InfinitySpin } from  'react-loader-spinner';

// import axios from "axios";

export function numberWithCommas(x){
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

const Carousal = () => {

  const { currency } = useContext(Context);


  const[trending, setTrending] = useState([]);
  const[loading, setLoading] = useState(false);

  const fetchTrendingCoins = async () => {
    try{
      setLoading(true);
      const data = await fetch(TrendingCoins(currency)).then((res) => res.json());
      if(data){
        setTrending(data);
        // console.log(data);
      setLoading(false);

      }

    }catch(err){
      console.log(err);
    }
 
  }

  useEffect(()=>{
    fetchTrendingCoins();
  },[currency])

  const items=trending.map((coin) => {
    let profit=coin.market_cap_change_percentage_24h>=0;
    return(
      <Link className="link" to={`./coins/${coin.id}`} key={coin.id}>
      
      <img src={coin.image} alt={coin.name} height="80" style={{marginBottom:10}}/><br/>
      <span>{coin?.name}</span><br/>
      <span>{coin?.symbol.toUpperCase()} &nbsp; <span className={profit>0 ? "crypto-profit" : "crypto-loss"}>{profit && "+"} {coin?.price_change_percentage_24h?.toFixed(2)} %</span>
       </span>
      <br/>
      <span>{currency==="INR" ? "₹" : "$"} {numberWithCommas(coin?.current_price.toFixed(2))}
      </span>

    
    </Link>


  )})

  return(
    <div className="carousal">
      {!loading ? <AliceCarousel 
        mouseTracking
        infinite
        autoPlayInterval={1000}
        animationDuration={1500}
        disableDotsControls
        disableButtonsControls
        // responsive={responsive}
        autoPlay
        items={items}
      /> :
      <InfinitySpin 
  width='200'
  color="#37887A"
/>}
      
    </div>
  )
}
export default Carousal;