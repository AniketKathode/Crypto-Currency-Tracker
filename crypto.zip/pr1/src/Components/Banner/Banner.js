import React,{useContext} from 'react';
import './Banner.css';

import {Context} from "../../App.js"


import Carousal from "./Carousal"

const Banner = () => {

  const { currency,setCurrency } = useContext(Context);


  return <div className="banner">

<select value={currency} className="currency" onChange={(e) => setCurrency(e.target.value)}>
        <option>INR</option>
        <option>USD</option>
      </select>

    <h1 className="banner_title">CRYPTO TRACKER</h1>
    <h4 className="banner_subtitle">Top 10 Trending CryptoCurrencies</h4>

    <Carousal/> 
   </div>;
};
export default Banner;
