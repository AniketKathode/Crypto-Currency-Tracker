import React,{useState,useEffect,useContext} from 'react';
import './CoinInfo.css';
// import {useParams} from "react-router-dom";


import {HistoricalChart} from "../../config/api.js";
import {Context} from "../../App.js";

import { Circles } from  'react-loader-spinner';


import {Line} from "react-chartjs-2";
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

const CoinInfo = ({coin}) => {
  // const{id} = useParams();

  const { currency } = useContext(Context);

  const[loading, setLoading] = useState(false);

  const[historicData, setHistoricData] = useState([]);
  const[days, setDays] = useState(1);

  const fetchCoin = async () => {
    try{
      setLoading(true);
      const data = await fetch(HistoricalChart(coin.id,days,currency)).then((res) => res.json());
      if(data){
        setHistoricData(data.prices);
        // console.log(data.prices);
        // setItems(data).fill(null).map((_, i) => i);
        // setItems(data);
      }
      setLoading(false);

    }catch(err){
      console.log(err);
    }
 
  }

  useEffect(()=>{
    fetchCoin();
  },[days])

  return (
    <div className="coin-info">
      {
        !historicData ? (<Circles
          height="80"
          width="80"
          color="white"
          ariaLabel="circles-loading"
          wrapperStyle={{}}
          wrapperClass=""
          visible={true}
        />) : 
        (
          <>
            <Line data={{
              labels:historicData?.map((coin) => {
                let date = new Date(coin[0]).toISOString().split('T')[0];
                let dat = new Date(coin[0]);
                let time = dat.getHours()>12 ? `${dat.getHours()-12}:${dat.getMinutes()}PM` : `${dat.getHours()}:${dat.getMinutes()}AM`
                return days===1 ?time : date;
              }),
              datasets:[{
                data:historicData.map((coin) => coin[1]),
                label:`Price(Past ${days} Days) in ${currency}`
              }]
            }}
            options={{
              elements:{
                point:{
                  radius:1
                }
              }
            }} />
          </>
        )
      }
      <br/>
      <div className="graph_buttons">
        <button className={days===1 ? "graph_btn_active":"graph_btn"} onClick={() => setDays(1)}>24 Hours</button>
        <button className={days===30 ? "graph_btn_active":"graph_btn"} onClick={() => setDays(30)}>30 Days</button>
        <button className={days===90 ? "graph_btn_active":"graph_btn"} onClick={() => setDays(90)}>3 Months</button>
        <button className={days===365 ? "graph_btn_active":"graph_btn"} onClick={() => setDays(365)}>1 Year</button>
      </div>
    </div>
  );
};
export default CoinInfo;
