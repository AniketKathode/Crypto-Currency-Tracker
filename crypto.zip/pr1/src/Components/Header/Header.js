import React,{useState, useContext} from "react";
import "./Header.css";
import {Context} from "../../App.js"
import {Link} from "react-router-dom"


const Header = () => {

  // const { currency,setCurrency } = useContext(Context);

  return(

    <div className="header">
          
      <div className="header_navbar">
      <Link to="/">
        <img className="crypto-logo" src="https://raw.githubusercontent.com/Siva-Tejaa/Projects-Data/main/CryptoTrackerLogo.png" alt="CryptoTracker Logo"/>
        </Link>
        <h1 className="crypto-text">RYPTO TRACKER</h1>
      
        </div>


    </div>

  )
}
export default Header;