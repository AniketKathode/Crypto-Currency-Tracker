import React from 'react';
import './Footer.css';

// import Context from '../Context';

export default function Footer() {

  // const {isDarkMode} = useContext(Context);

  const date = new Date();
  return (
    <div>
      <footer>
        <section className="footer_section">
          <p>
            <span id="displayYear"></span>Copyright @ {date.getFullYear()}
            {/* <a href=""> SivaTeja</a> */}
          </p>
        </section>
      </footer>
      {/* {console.clear()} */}
    </div>
  );
}
