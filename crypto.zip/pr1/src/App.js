import React,{useState,createContext} from 'react';
import './App.css';

import Header from './Components/Header/Header';
import HomePage from './Pages/HomePage/HomePage';
import CoinPage from './Pages/CoinPage/CoinPage';

import Footer from './Components/Footer/Footer';

import { BrowserRouter, Routes, Route } from 'react-router-dom';

export const Context = createContext();

export default function App() {

  const[currency, setCurrency] = useState("USD")


  return (
    <BrowserRouter>
      <center>
        {/* <h1>Crypto Tracker</h1> */}
        <Context.Provider value={{currency,setCurrency}}>
        <Header />
        <Routes>
          <Route exact path="/" element={<HomePage />} />
          <Route exact path="/coins/:id" element={<CoinPage />} />
        </Routes>
        <Footer/>
        </Context.Provider>

      </center>
    </BrowserRouter>
  );
}
